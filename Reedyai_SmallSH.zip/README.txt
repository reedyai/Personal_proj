Use the command below to complie the code:

gcc main.c -o smallsh

